from queue import PriorityQueue
import random
from memory_profiler import profile
import time
import math

class Node:
    def __init__(self, state, move, parent, depth):
        self.state = state
        self.move = move
        self.parent = parent
        self.depth = depth
        self.heuristic = 0

    def __lt__(self, other):
        return (self.depth + self.heuristic) < (other.depth + other.heuristic)

#############################################################################################################################

def print_puzzle(state, n):
    print("-" * (n * 4 + n + 1))
    for i in range(0, len(state), n):
        print("|", end="")
        for j in range(n):
            cell = state[i + j]
            if cell == 0:
                print("    |", end="")
            else:
                print(f" {cell:2d} |", end="")
        print("\n" + "-" * (n * 4 + n + 1))

def print_solution(paths, start, goal, n):
    if paths == None:
        print( "No solution found")
        return
    elif paths == [None]:
        print( "Start node was the goal!")
        return
    
    curr = start
    #print(start, end = " -> \n\n")
    for path in paths:
        curr = move(curr, path, n)
        print_puzzle(curr, n)
        if curr != goal:
            print("\n")
        
    if curr != goal: 
        print_puzzle(goal, n)
    print(paths, end = "\n")  
  
#############################################################################################################################
  
def swap(state, current_position, new_position):
    temp = state[new_position]
    state[new_position] = state[current_position]
    state[current_position] = temp
    
def move(state, direction, n):
    # Get position of the blank space
    blank_position = state.index(0)
    new_blank_position = blank_position
    if direction == "up" and blank_position not in range(0, n, 1):
        new_blank_position = blank_position - n
    elif direction == "down" and blank_position not in range((n - 1) * n, n * n, 1):
        new_blank_position = blank_position + n
    elif direction == "left" and blank_position not in range(0, (n - 1) * n, n):
        new_blank_position = blank_position - 1
    elif direction == "right" and blank_position not in range(n - 1, n * n, n):
        new_blank_position = blank_position + 1
    
    if new_blank_position == blank_position:
        return None
    
    new_state = state.copy()  # Make a copy of the state
    swap(new_state, blank_position, new_blank_position)
    return new_state

def expand_successors(node, n):
    directions = ["up", "down", "left", "right"]
    expanded_list = []
    for direction in directions:
        new_state = move(node.state, direction, n)
        if new_state is not None:
            expanded_list.append(Node(new_state, direction, node, node.depth + 1))
            
    return expanded_list

#############################################################################################################################
@profile
def uniform_cost_search(start, goal, n):
    frontier = PriorityQueue()
    start_node = Node(start, None, None, 0)
    frontier.put((0, start_node))
    explored = set()
    
    while frontier:
        _, current_node = frontier.get()
        
        if current_node.state == goal:
            path = []
            while current_node.parent:
                path.insert(0, current_node.move)
                current_node = current_node.parent
            print_solution(path, start, goal, n)
            return path
        
        if tuple(current_node.state) in explored:
            continue
        
        explored.add(tuple(current_node.state))
        
        successors = expand_successors(current_node, n)
        for successor in successors:
            successor.depth += current_node.depth
            frontier.put((successor.depth, successor))
    
    return None  # If no path is found

#############################################################################################################################
def count_vertical_inversion(state, n, col):
    total_inversion = 0
    for i in range(col, n * n, n):
        for j in range (i + n, n * n, n):
            if state[i] > state[j] and state[i] != 0 and state[j] != 0:
                total_inversion += 1
            elif state[i] < state[j] and state[i] != 0 and state[j] != 0:
                total_inversion -=1
                
    return total_inversion

def count_horizontal_inversion(state, n, row):
    total_inversion = 0
    for i in range(row, row + n):
        for j in range (i + 1, row + n):
            if state[i] > state[j] and state[i] != 0 and state[j] != 0:
                total_inversion += 1
            elif state[i] < state[j] and state[i] != 0 and state[j] != 0:
                total_inversion -=1
    
    return total_inversion

def get_heuristic(state, n):
    vertical_inversion = sum(count_vertical_inversion(state, n, col) for col in range(n))
    horizontal_inversion = sum(count_horizontal_inversion(state, n, row) for row in range(n))
    
    return vertical_inversion + horizontal_inversion
        

@profile
def A_star(start, goal, n):
    frontier = PriorityQueue()
    start_node = Node(start, None, None, 0)
    frontier.put((0, start_node))
    explored = set()
    
    while frontier:
        _, current_node = frontier.get()
        
        if current_node.state == goal:
            path = []
            while current_node.parent:
                path.insert(0, current_node.move)
                current_node = current_node.parent
            print_solution(path, start, goal, n)
            return path
        
        if tuple(current_node.state) in explored:
            continue
        
        explored.add(tuple(current_node.state))
        
        successors = expand_successors(current_node, n)
        for successor in successors:
            successor.depth += current_node.depth
            successor.heuristic = get_heuristic(successor.state, n)
            successor.heuristic += successor.depth
            frontier.put((successor.heuristic, successor))
    
    return None  # If no path is found

#############################################################################################################################
def generate_random_list(n):
    nums = list(range(n))
    random.shuffle(nums)
    return nums


def main():
    
    print("N-puzzle")
    n = int(input("Please enter number of puzzles (it should be 8, 15, ...): n = "))
    print("Searching Algorithm\n1.UCS\n2.A*")
    search_option = int(input("Please enter a number for a searching algorithm (1, 2): "))
    
    start = generate_random_list(n + 1)
    #start = [1, 3, 0, 4, 2, 5,  7, 8, 6]
    #start = [5, 1, 3, 4, 2, 0, 7, 8, 9, 6, 10, 12, 13, 14, 11, 15]
    #start = [7, 1, 3, 4, 5, 6, 13, 2, 9, 10, 11, 12, 0, 8, 14, 15, 17, 18, 19, 20, 21, 16, 22, 23, 25, 26, 27, 28, 29, 24, 31, 32, 33, 34, 35, 30]
    goal = list(range(1, n + 1)) + [0]
    start_time = 0
    end_time = 0
    size_board = int(math.sqrt(n + 1))
    print (f"Initial state:")
    print_puzzle(start, size_board)
    print("")
    if search_option == 1:
        start_time = time.time()
        result = uniform_cost_search(start, goal, size_board)
        end_time = time.time()
        
    elif search_option == 2:
        start_time = time.time()
        result = A_star(start, goal, size_board)
        end_time = time.time()
        
    else:
        print("Invalid!")
        main()
        
    execution_time = end_time - start_time
    print(f"Running time: {execution_time * 1000} (ms)")

if __name__ == "__main__":
    main()
